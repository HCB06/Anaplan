import numpy as np
from sklearn.datasets import load_wine
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.metrics import f1_score
import plan
from colorama import Fore
import time


wine = load_wine()
X = wine.data
y = wine.target

one_hot_encoder = OneHotEncoder(sparse=False)
y = one_hot_encoder.fit_transform(y.reshape(-1, 1))


X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.4, random_state=17903)


scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)
X_train = X_train.tolist()
X_test = X_test.tolist()
y_train = y_train.tolist()
y_test = y_test.tolist()


ClassCount = 3
Layers = ['fex', 'cat']
Neurons = [6, 3] 
MembranThresholds = ['<', '=='] 
MembranPotentials = [0.01, 0]
Activations = ['none', 'none']  
Normalizations = ['n', 'n'] 


Train = plan.TrainPLAN(X_train, y_train, ClassCount, Layers, Neurons,
                                      MembranThresholds, MembranPotentials, Normalizations, Activations)

W = Train[plan.GetWeights()]



Test = plan.TestPLAN(X_test, y_test, Layers, MembranThresholds, MembranPotentials,
                                          Normalizations, Activations, W)


TestPreds = Test[plan.GetPreds()]
TestAcc = Test[plan.GetAcc()]

TestPreds = np.array(TestPreds)
y_test = np.array(y_test)


ModelName = 'wine_classification'
ModelType = 'PLAN'
LogType = 'txt'
WeightsType = 'txt'
WeightsFormat = 'raw'
ModelPath = 'PlanModels/'


y_test = np.argmax(y_test, axis=1)


f1 = f1_score(y_test, TestPreds, average='weighted')
print(f1)


plan.SavePLAN(ModelName, ModelType, Layers, 3, MembranThresholds, MembranPotentials, Normalizations, Activations, TestAcc, LogType, WeightsType, WeightsFormat, ModelPath, W)

for i in range(len(X_test)):
    Predict = plan.PredictFromRamPLAN(X_test[i], Layers, MembranThresholds, MembranPotentials, Normalizations, Activations, W)
    time.sleep(0.6)
    if np.argmax(Predict) == y_test[i]:
        print(Fore.GREEN + 'Predicted Output(index):', np.argmax(Predict), 'Real Output(index):', y_test[i])
    else:
        print(Fore.RED + 'Predicted Output(index):', np.argmax(Predict), 'Real Output(index):', y_test[i])
