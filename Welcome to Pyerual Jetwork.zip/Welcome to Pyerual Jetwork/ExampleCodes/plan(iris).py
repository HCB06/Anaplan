from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, OneHotEncoder
import plan
import numpy as np
import time
from colorama import Fore

iris = load_iris()
X = iris.data
y = iris.target



X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.27, random_state=976)


scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

encoder = OneHotEncoder()
TrainLabels = encoder.fit_transform(y_train.reshape(-1, 1)).toarray()
TestLabels = encoder.transform(y_test.reshape(-1, 1)).toarray()

TrainInputs = X_train_scaled.tolist()
TestInputs = X_test_scaled.tolist()

ClassCount = 3  


Layers = ['fex', 'cat']
Neurons = [100, ClassCount]
ThresholdSigns = ['<', '==']
ThresholdValues = [0.01, 0]
Activations = ['none', 'none'] 
Normalizations = ['y', 'n']  


Train = plan.TrainPLAN(TrainInputs, TrainLabels, ClassCount, Layers, Neurons,
                                      ThresholdSigns, ThresholdValues, Normalizations, Activations)

W = Train[plan.GetWeights()]

Test = plan.TestPLAN(TestInputs, TestLabels, Layers, ThresholdSigns, ThresholdValues,
Normalizations, Activations, W)

TestPreds = Test[plan.GetPreds()]
TestAcc = Test[plan.GetAcc()]

ModelName = 'iris'
ModelType = 'PLAN'
LogType = 'txt'
WeightsType = 'txt'
WeightsFormat = 'raw'
ModelPath = 'PlanModels/'


plan.SavePLAN(ModelName, ModelType, Layers, ClassCount, ThresholdSigns, ThresholdValues, Normalizations, Activations, TestAcc, LogType, WeightsType, WeightsFormat, ModelPath, W)

for i in range(len(TestInputs)):
    Predict = plan.PredictFromRamPLAN(TestInputs[i], Layers, ThresholdSigns, ThresholdValues, Normalizations, Activations, W)
    time.sleep(0.6)
    if np.argmax(Predict) == np.argmax(TestLabels[i]):
        print(Fore.GREEN + 'Predicted Output(index):', np.argmax(Predict), 'Real Output(index):', np.argmax(TestLabels[i]))
    else:
        print(Fore.RED + 'Predicted Output(index):', np.argmax(Predict), 'Real Output(index):', np.argmax(TestLabels[i]))
        
        
        
        

        
        
        